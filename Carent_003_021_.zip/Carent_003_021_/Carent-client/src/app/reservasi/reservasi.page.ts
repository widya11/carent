import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservasi',
  templateUrl: './reservasi.page.html',
  styleUrls: ['./reservasi.page.scss'],
})
export class ReservasiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
