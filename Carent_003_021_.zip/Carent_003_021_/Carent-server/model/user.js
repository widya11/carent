var pool = require('./databaseConfig.js');
var carentDB = {
    getUsers: function (callback) {
        pool.getConnection(function (err, conn) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                console.log("Connected!");
                var sql = 'SELECT * FROM user';
                conn.query(sql, function (err, result) {
                    conn.release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    }
    ,
    /* end function getUser */
    addUser: function (first_name, last_name, email, password, phone_number, callback) {
        pool.getConnection(function (err, conn) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                console.log("Connected!");
                var sql = 'INSERT INTO user (first_name, last_name, email, password, phone_number) values (?, ?, ?, ?, ?)';
                conn.query(sql, [first_name, last_name, email, password, phone_number], function (err, result) {
                    conn.release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    }
    ,
    deleteUser: function (userid, callback) {
        pool.getConnection(function (err, conn) {
            if (err) {
                console.log(err);
                return callback(err,null);
            }
            else {
                console.log("Connected!");
                var sql = 'DELETE FROM user WHERE userid=?';
                conn.query(sql, [userid], function (err, result) {
                    conn.release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    }
    ,
updateUser: function (first_name, last_name, email, password, phone_number, userid,   callback) {
    pool.getConnection(function (err, conn) {
        if (err) {
            console.log(err);
            return callback(err,null);
        }
        else {
            console.log("Connected!");
            console.log(fisrt_name+", "+last_name+", "+email+",  "+password+", "+phone_number+", "+userid)
            var sql = 'UPDATE user SET first_name=?, last_name=?, email=?, password=?, phone_number=?,  WHERE userid=?';
            conn.query(sql, [first_name, last_name, email, password, phone_number, userid], function (err, result) {
                conn.release();
                if (err) {
                    console.log(err);
                    return callback(err, null);
                } else {
                    console.log(result);
                    return callback(null, result);
                }
            });
        }
    });
}
}
module.exports = carentDB