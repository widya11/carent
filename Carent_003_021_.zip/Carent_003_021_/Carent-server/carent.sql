-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2019 at 04:37 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carent`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `deskripsi` varchar(300) NOT NULL,
  `tahun` int(10) NOT NULL,
  `warna` text NOT NULL,
  `nomor_polisi` varchar(100) NOT NULL,
  `harga` int(255) NOT NULL,
  `rental` text NOT NULL,
  `kontak` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`deskripsi`, `tahun`, `warna`, `nomor_polisi`, `harga`, `rental`, `kontak`) VALUES
('All New Avanza merupakan salah satu jenis mobil yang paling banyak digunakan di Indonesia, mobil ini adalah pilihan terbaik jika anda ingin liburan dengan keluarga besar atau teman.', 2017, 'Silver', 'BP 1583 EA', 400000, 'Belum di rental', 812665985);

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `tanggal_penjemputan` date NOT NULL,
  `tanggal_pengembalian` date NOT NULL,
  `lokasi_penjemputan` varchar(100) NOT NULL,
  `jam_penjemputan` time NOT NULL,
  `durasi` varchar(100) NOT NULL,
  `pembayaran` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_number` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`first_name`, `last_name`, `email`, `password`, `phone_number`) VALUES
('faradina perdana', 'jodanayang', 'faradinapj19@gmail.com', 'mypassword', 895364441),
('widya putri', 'ramadhani', 'widyap402@gmail.com', 'mypassword', 812682536);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`nomor_polisi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
