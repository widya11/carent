var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var jsonParser = bodyParser.json();
var path = require('path');
var cors = require("cors")
var cor = cors();
app.use(cor);
app.use(express.static(path.join(__dirname, "../public")));
var user = require('../model/user');
var car = require('../model/car');

app.get('/api/user', function (req, res) {
    user.getUsers(function (err, result) {
        if (!err) {
            res.send(result);
        }
        else {
            console.log(err);
            //res.status(500).send(err);
            res.send(err);
        }
    })
})

app.post('/api/user', urlencodedParser, jsonParser, function (req, res) {
    var first_name = req.body.first_name;
    var last_name = req.body.last_name;
    var email = req.body.email;
    var password = req.body.password;
    var phone_number = req.body.phone_number;

    user.addUser(first_name, last_name, email, password, phone_number, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + 'record ditambahkan');
        }
        else {
            console.log(err);
            //res.status(500).send(err.code);
            res.send(err);
        }
    })
})
app.delete('/api/user/:userid', function (req, res) {
    var userid =req.params.userid;

    user.deleteUser(userid, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + 'record dihapus');
        } else {
            console.log(err);
            //res.status(500).send(err.code);
            res.send(err);
        }
    });
});
app.post('/api/user/:userid', urlencodedParser, jsonParser, function (req, res) {
    var first_name = req.body.first_name;
    var last_name = req.body.last_name;
    var email = req.body.email;
    var password = req.body.password;
    var phone_number = req.body.phone_number;
    var userid = req.params.userid;
    
    user.updateUser(first_name, last_name, email, password, phone_number, userid, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + 'record diubah');
        } else {
            console.log(err);
            // res.status(500).send(err.code);
            res.send(err);
        }
    })
})

app.get('/api/car', function (req, res) {
    car.getCars(function (err, result) {
        if (!err) {
            res.send(result);
        }
        else {
            console.log(err);
            //res.status(500).send(err);
            res.send(err);
        }
    })
})
module.exports = app