-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Apr 2019 pada 08.17
-- Versi server: 10.1.36-MariaDB
-- Versi PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carent`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `car`
--

CREATE TABLE `car` (
  `deskripsi` varchar(300) NOT NULL,
  `tahun` int(10) NOT NULL,
  `warna` text NOT NULL,
  `nomor_polisi` varchar(100) NOT NULL,
  `harga` int(255) NOT NULL,
  `rental` text NOT NULL,
  `kontak` int(100) NOT NULL,
  `images` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `car`
--

INSERT INTO `car` (`deskripsi`, `tahun`, `warna`, `nomor_polisi`, `harga`, `rental`, `kontak`, `images`) VALUES
('All New Alphard merupakan salah satu jenis mobil yang paling banyak digunakan di Indonesia, mobil ini adalah pilihan terbaik jika anda ingin liburan dengan keluarga besar atau teman.', 2018, 'Black', 'BP 1234 MK', 500000, 'Di rental', 123456789, '\"http://localhost:8081/img/alphard-black.png\"'),
('All New Avanza merupakan salah satu jenis mobil yang paling banyak digunakan di Indonesia, mobil ini adalah pilihan terbaik jika anda ingin liburan dengan keluarga besar atau teman.', 2017, 'Silver', 'BP 1583 EA', 400000, 'Belum di rental', 812665985, '\"http://localhost:8081/img/avanza-white.png\"'),
('All New Xenia merupakan salah satu jenis mobil yang paling banyak digunakan di Indonesia, mobil ini adalah pilihan terbaik jika anda ingin liburan dengan keluarga besar atau teman.', 2018, 'Black', 'BP 8735 LM', 450000, 'Belum Di Rental', 123456789, '\"http://localhost:8081/img/xenia-black.png\"');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rental`
--

CREATE TABLE `rental` (
  `tanggal_penjemputan` date NOT NULL,
  `tanggal_pengembalian` date NOT NULL,
  `lokasi_penjemputan` varchar(100) NOT NULL,
  `jam_penjemputan` time NOT NULL,
  `durasi` varchar(100) NOT NULL,
  `pembayaran` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userid` int(100) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userid`, `first_name`, `last_name`, `email`, `password`, `phone_number`) VALUES
(1, 'widya putri', 'ramadhani', 'widyaputri@gmail.com', 'mypass', 812682536),
(2, 'faradina perdana', 'jodanayang', 'faradinaperdana@gmail.com', 'mypass', 812345678),
(3, 'widya yolanda', 'melisa', 'ulfasarimelisa04@gmail.com', 'mypassword', 812665985);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`nomor_polisi`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
