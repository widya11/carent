var pool = require('./databaseConfig.js');
var carentDB = {
    addRental: function (tanggal_pengambilan, tanggal_pengembalian, durasi, pembayaran, callback) {
        pool.getConnection(function (err, conn) {
            if (err) {
                console.log(err);
                return callback(err, null);
            }
            else {
                console.log("Connected!");
                var sql = 'INSERT INTO rental (tanggal_pengambilan, tanggal_pengembalian, durasi, pembayaran) values (?, ?, ?, ?)';
                conn.query(sql, [tanggal_pengambilan, tanggal_pengembalian, durasi, pembayaran], function (err, result) {
                    conn.release();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                });
            }
        });
    }
}
module.exports = carentDB