import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.page.html',
  styleUrls: ['./auth.page.scss'],
})
export class AuthPage implements OnInit {

  constructor(public storage: Storage, public router: Router) { }

  async ngOnInit() {
    const loggedIn = await this.storage.get('userData');
    if(loggedIn) {
      return this.router.navigate(['utama'], { replaceUrl: true });
    }
    return this.router.navigate(['login'], { replaceUrl: true });
  }

}
