import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservasiPage } from './reservasi.page';

describe('ReservasiPage', () => {
  let component: ReservasiPage;
  let fixture: ComponentFixture<ReservasiPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReservasiPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservasiPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
