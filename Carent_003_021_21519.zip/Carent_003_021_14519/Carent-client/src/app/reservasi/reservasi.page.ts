import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { CarService } from '../car.service';
@Component({
  selector: 'app-reservasi',
  templateUrl: './reservasi.page.html',
  styleUrls: ['./reservasi.page.scss'],
})
export class ReservasiPage implements OnInit {
  tanggal_pengambilan: any;
  tanggal_pengembalian: any;
  durasi: any;
  pembayaran: any;
  
  constructor(public alertController: AlertController, private carService: CarService) { }
  async presentAlert(){
    this.carService.reservasi(this.tanggal_pengambilan, this.tanggal_pengembalian, this.durasi, this.pembayaran).subscribe(async response => {
      if (response) {
        this.alert();
      }
    })
  }

  async alert() {
    const alert = await this.alertController.create({
      header: 'Carent',
      message: 'Pesanan mobil anda sudah berhasil :)',
      buttons: ['OK']
    });
    await alert.present();
  }

  ngOnInit() {}
}
