import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { ToastController } from '@ionic/angular';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(public http: Http, public toastController: ToastController) { }
  loadUser(){
    return this.http.get('http://localhost:3000/api/user/');
  }
  addUser(data){
    return this.http.get('http://localhost:3000/api/user/', data);
  }
  async message(msg){
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000
    });
    toast.present();
  }
}
