import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor(public http: Http) { }
  loadCar(){
    return this.http.get('http://localhost:3000/api/car');
  }

  login(email, password) {
    return this.http.post('http://localhost:3000/api/user/auth/login', {
      email,
      password
    });
  }

  reservasi(tanggal_pengambilan, tanggal_pengembalian, durasi, pembayaran) {
    return this.http.post('http://localhost:3000/api/rental', {
      tanggal_pengambilan,
      tanggal_pengembalian,
      durasi,
      pembayaran
    });
  }
}
