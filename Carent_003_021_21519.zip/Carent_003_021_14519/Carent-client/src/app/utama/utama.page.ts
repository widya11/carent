import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CarService } from '../car.service';
import { Response } from '@angular/http';
import { DomSanitizer } from '@angular/platform-browser';
import { BookingPage } from '../booking/booking.page';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-utama',
  templateUrl: './utama.page.html',
  styleUrls: ['./utama.page.scss'],
})
export class UtamaPage implements OnInit {
  carList: any;
  constructor(public router: Router, public carService: CarService, public sanitization: DomSanitizer, private modalController: ModalController) {
    this.loadCar();
  }
  loadCar() {
    this.carService.loadCar().subscribe((response: Response) => {
      let data = response.json();
      for (let elem of data) {
        elem.images = elem.images.split(',');
      }
      this.carList = data;
      this.carList.map(val => {
        val.images = this.sanitization.bypassSecurityTrustStyle(`url(${val.images})`);
        return {
          ...val
        }
      });
      console.log(this.carList);
    });
  }
  ngOnInit() {
  }
  goHome() {
    this.router.navigate(['/home']);
  }
  goAkun() {
    this.router.navigate(['/akun']);
  }
  goReservasi() {
    this.router.navigate(['/reservasi']);
  }
  async goBooking(data) {
    const modal = await this.modalController.create({
      component: BookingPage,
      componentProps: {
        data
      }
    });
    return await modal.present();
  }
}
