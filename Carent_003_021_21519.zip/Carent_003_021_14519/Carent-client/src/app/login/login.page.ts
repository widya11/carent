import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Storage } from '@ionic/storage';
import { CarService } from '../car.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: any;
  password: any;
  constructor(public router: Router, public storage: Storage, public service: CarService) { }
  ngOnInit() {} 
  goUtama(){
    this.service.login(this.username, this.password).subscribe(async response => {
      await this.storage.set('userData', response);
      return this.router.navigate(['utama']);
    });
  }
  goHome(){
    this.router.navigate(['/home']);
  }
}
