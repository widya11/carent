import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'registrasi', loadChildren: './registrasi/registrasi.module#RegistrasiPageModule' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'akun', loadChildren: './akun/akun.module#AkunPageModule' },
  { path: 'booking', loadChildren: './booking/booking.module#BookingPageModule' },
  { path: 'reservasi', loadChildren: './reservasi/reservasi.module#ReservasiPageModule' },
  { path: 'utama', loadChildren: './utama/utama.module#UtamaPageModule' },
  { path: 'auth', loadChildren: './auth/auth.module#AuthPageModule' },
  { path: 'user-add', loadChildren: './user-add/user-add.module#UserAddPageModule' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
