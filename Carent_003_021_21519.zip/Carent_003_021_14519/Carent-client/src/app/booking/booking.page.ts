import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CarService } from '../car.service';
import { Response } from '@angular/http';
import { DomSanitizer } from '@angular/platform-browser';
import { NavParams, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.page.html',
  styleUrls: ['./booking.page.scss'],
})
export class BookingPage implements OnInit {
  car: any;
  constructor(public router: Router, public carService: CarService, public sanitization: DomSanitizer, private params: NavParams, private modal: ModalController) { 
   }
  ngOnInit() {
    const data = this.params.data;
    this.car = data.data;
  }
  goUtama(){
    this.router.navigate(['/utama']);
  }
  async goReservasi(){
    await this.modal.dismiss();
    this.router.navigate(['/reservasi']);
  }
}
