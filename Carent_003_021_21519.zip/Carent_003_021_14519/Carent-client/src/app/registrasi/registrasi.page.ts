import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Response } from '@angular/http';
import { UserService } from '../user.service';
import { ModalController } from '@ionic/angular';
import { UserAddPage } from '../user-add/user-add.page';
@Component({
  selector: 'app-registrasi',
  templateUrl: './registrasi.page.html',
  styleUrls: ['./registrasi.page.scss'],
})
export class RegistrasiPage implements OnInit {
  userList: any;
  constructor(
    public router: Router,
    public userService: UserService,
    public modalController: ModalController) {
      this.loadUser();
     }
     loadUser(){
       this.userService.loadUser().subscribe((response: Response) => {
         this.userList = response.json();
         console.log(this.userList);
       });
     }
     async goAddUser(){
       const modal = await this.modalController.create({
         component: UserAddPage
       });
       modal.onDidDismiss().then(() => {this.loadUser() });
       return await modal.present();
     }
  ngOnInit() {
  }
  goUtama(){
    this.router.navigate(['/utama']);
  }
  goHome(){
    this.router.navigate(['/home']);
  }

}
